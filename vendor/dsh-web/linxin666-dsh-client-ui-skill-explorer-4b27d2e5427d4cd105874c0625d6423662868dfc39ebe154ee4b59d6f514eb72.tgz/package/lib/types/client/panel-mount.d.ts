import type { SkillApi } from './api.ts';
import type { LocaleRefreshSource } from './sidebar-entry.ts';
/** Mounted panel controller: toggle/open/close plus the disposer. */
export interface SkillPanelMount {
    toggle: () => void;
    open: () => void;
    close: () => void;
    dispose: () => void;
}
/**
 * Mount the skill center overlay panel.
 * @param api - the skill center API client.
 * @param locale - locale-change source; when given, re-renders an open panel
 *   on a Language switch.
 * @returns controller (toggle/open/close) and the disposer.
 */
export declare function mountPanel(api: SkillApi, locale?: LocaleRefreshSource): SkillPanelMount;
