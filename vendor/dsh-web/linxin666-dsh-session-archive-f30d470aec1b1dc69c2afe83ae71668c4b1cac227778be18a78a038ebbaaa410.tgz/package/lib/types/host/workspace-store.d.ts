/**
 * Workspace-domain mutations for dsh-session-archive. The alpha.2 SDK has a
 * public archive verb (`workspaceRegistry.archiveSession`) but no unarchive,
 * so unarchive and workspace-row cleanup go through the registry's durable
 * domain handles (`requireState`/`setState` for the global archive set,
 * entity `mutate` for workspace rows). Both writes flow through the domain
 * storage, so the workspace feed publishes follow frames and every connected
 * browser sees the change without a reload. The seams are feature-detected
 * and pinned to the SDK cohort; when absent, operations fail with
 * `missing-seam` instead of guessing at files.
 * @module @linxin666/dsh-session-archive/host/workspace-store
 */
import type { Context } from '@deepseek-ai/cordis';
export interface WorkspaceRecordLike {
    path: string;
    title: string;
    sessionIds: string[];
    createdAt: string;
    updatedAt: string;
}
/** Whether the unarchive seam is present on this registry instance. */
export declare function unarchiveSeamAvailable(registry: unknown): boolean;
/**
 * Remove ids from the registry-global archive set durably. Idempotent: ids
 * not in the set are ignored. Emits the domain `put` change so the workspace
 * feed publishes `{ type: 'archived' }` follow frames.
 */
export declare function unarchiveSessions(registry: unknown, ids: readonly string[]): Promise<void>;
/**
 * Archive one session through the public verb. Idempotent for already
 * archived ids; throws when the session does not exist live or in
 * persistence.
 */
export declare function archiveSession(ctx: Context, id: string): Promise<void>;
/**
 * Remove ids from every workspace's durable `sessionIds` account. Goes
 * through the entity `mutate` path (durable table update + record refresh +
 * feed upsert). Returns the ids actually removed from at least one row.
 */
export declare function removeFromWorkspaceRows(registry: unknown, ids: readonly string[]): Promise<string[]>;
