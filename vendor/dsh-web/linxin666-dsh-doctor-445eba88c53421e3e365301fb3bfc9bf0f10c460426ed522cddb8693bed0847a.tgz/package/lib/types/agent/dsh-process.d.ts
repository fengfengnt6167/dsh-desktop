import { type SpawnOptions } from 'node:child_process';
/** Build the exact cmd.exe argument vector required to execute a trusted .cmd shim. */
export declare function windowsCmdShimArgs(binary: string, args: readonly string[]): string[];
export interface DshSpawnSpec {
    command: string;
    args: string[];
    windowsVerbatimArguments?: boolean;
}
export declare function dshSpawnSpec(binary: string, args: readonly string[], platform?: NodeJS.Platform): DshSpawnSpec;
/** Spawn the official DSH CLI, including the Windows .cmd shim path. */
export declare function spawnDsh(binary: string, args: readonly string[], options: Pick<SpawnOptions, 'env' | 'stdio'>, platform?: NodeJS.Platform): import("child_process").ChildProcess;
