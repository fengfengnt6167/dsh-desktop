/**
 * Legacy OS-service cleanup. Doctor supervisors used to run as persistent
 * login services (a macOS LaunchAgent, a systemd --user unit, a Windows
 * scheduled task) registered by the host on every boot: the registration was
 * global state written with the registering boot's own paths, so any host —
 * dev, e2e, or the desktop app — hijacked the same plist and the daemon
 * outlived every process cleanup. Supervisors now run as host-bounded child
 * processes (see host/ensure.ts); this module only removes the old
 * registrations, idempotently, so the first boot of the new doctor migrates
 * machines that still carry one.
 */
export interface LegacyServicePlan {
    /** Definition files to delete. */
    files: string[];
    /** Unregister command (launchctl bootout / systemctl disable / schtasks delete). */
    uninstall: string[];
}
export declare function legacyServicePlan(platform: NodeJS.Platform, env?: NodeJS.ProcessEnv, home?: string): LegacyServicePlan;
export type ServiceRunner = (command: string[]) => Promise<void>;
export declare function runCommand(command: string[], timeoutMs?: number): Promise<void>;
/**
 * Remove any legacy OS service registration. Returns true when definition
 * files existed (the unregister command still runs best-effort either way —
 * a registration can outlive its files). Never throws for a missing or
 * already-removed registration.
 */
export declare function removeLegacyService(run?: ServiceRunner, env?: NodeJS.ProcessEnv, home?: string): Promise<boolean>;
