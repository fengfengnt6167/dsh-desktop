import { type SupervisorRequest, type SupervisorResponse } from '../core/protocol.ts';
import { type DoctorPaths } from './paths.ts';
export interface SupervisorOptions {
    paths?: DoctorPaths;
    version?: string;
    now?: () => string;
    heartbeatTimeoutMs?: number;
    /** Capsule provisioning seam; tests inject a fake and skip real dsh runs. */
    provisioner?: (paths: DoctorPaths) => Promise<void>;
    /** Invoked once when an IPC `shutdown` action arrives; the supervisor keeps
     *  answering the current request and the callback decides how to exit. */
    onShutdown?: () => void;
}
export declare class DoctorSupervisor {
    readonly paths: DoctorPaths;
    private state;
    private token;
    private server?;
    private sweep?;
    private readonly version;
    private readonly now;
    private readonly heartbeatTimeoutMs;
    private readonly provisioner;
    private readonly onShutdown;
    private provisioning;
    lastSelfHeal: Promise<void> | undefined;
    constructor(options?: SupervisorOptions);
    start(): Promise<void>;
    stop(): Promise<void>;
    handleWire(body: string): Promise<SupervisorResponse>;
    handle(request: SupervisorRequest): Promise<SupervisorResponse>;
    /**
     * Self-heal one boot failure: attribute the error trace to a plugin row,
     * and when exactly one row is implicated, disable it in the profile patch
     * so the next `dsh web` boots without it. Debounced by the profile's
     * recent-failure window (recordFailure already ran; the second failure in
     * ten minutes is the trigger). Refuses to act when attribution is absent
     * or ambiguous — a wrong guess would disable a healthy plugin.
     */
    private selfHealBootFailure;
    /**
     * Run the deterministic recovery workflow for one incident; records the outcome on the incident.
     */
    private runRecovery;
    /**
     * Enter the provisioning phase and refresh the rescue capsule in the
     * background. The IPC response returns immediately with the provisioning
     * snapshot; the outcome (armed or degraded) is persisted when the capsule
     * run settles. Concurrent provision requests are coalesced.
     */
    startProvision(): Promise<void>;
    private finishProvision;
    private runCapsuleProvision;
    private cleanupCapsuleCredentials;
    private locateDsh;
    private persistQueue;
    /** Serialized persist: concurrent handle/sweep writes queue instead of racing on the temp file. */
    private persist;
    private sweepHeartbeats;
}
/**
 * Poll one pid until it is gone (`kill(pid, 0)` fails with ESRCH) and invoke
 * the callback. EPERM means the process exists under another account and is
 * treated as alive. This is the parent-liveness watch that bounds a
 * supervisor spawned as a host child: when the spawning host dies without a
 * graceful shutdown, the supervisor stops instead of lingering as an orphan.
 * Returns a stop function; the timer never keeps the event loop alive.
 */
export declare function watchParentPid(parentPid: number, onDead: () => void, intervalMs?: number): () => void;
export declare function runSupervisor(options?: {
    parentPid?: number;
}): Promise<void>;
