/**
 * Host loader entry for the dsh-model-capabilities plugin — runs in the DSH host process.
 *
 * Registers the plugin's own settings namespace `dsh-model-capabilities`,
 * which stores the profiles of disabled providers: disabling a custom pi-ai
 * provider stashes its profile here and unsets `llm-pi-ai.providers.<route>`
 * (the official Remove-provider seam), which unregisters the route and takes
 * the provider out of the model catalog that both the composer picker and the
 * subagent selection read; enabling restores the profile. The namespace holds
 * configuration only — API keys stay in the credentials service and are
 * untouched by a toggle.
 * @module @linxin666/dsh-client-ui-model-capabilities
 */
import type { Context } from '@deepseek-ai/cordis';
import z from 'schemastery';
/** Stable cordis plugin name (matches cordis.patch.yml insert id). */
export declare const name = "ui-model-capabilities";
/** Plugin config: the disabled-provider archive, keyed by provider route id. */
export interface Config {
    /** route id -> stashed provider profile (plus its display name). */
    disabled?: Record<string, unknown>;
}
export declare const Config: z<Config>;
/** Register the namespace (once per process; the family bundle may add a second row). */
export declare const apply: typeof applyImpl;
declare function applyImpl(ctx: Context): void;
export {};
