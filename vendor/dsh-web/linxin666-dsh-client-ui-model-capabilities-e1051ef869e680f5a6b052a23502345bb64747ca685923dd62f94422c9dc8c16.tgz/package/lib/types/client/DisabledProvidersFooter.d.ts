/**
 * Models-page footer extension area: the disabled-provider archive listing.
 *
 * A disabled provider's route is unregistered, so for hand-declared routes
 * the provider card itself disappears from the Models page; this footer (the
 * page's `settings.models.footer` seat) is where those providers come back:
 * it lists the archive entries whose route is still down and restores a profile
 * on enable. Renders nothing while no such entry exists.
 * @module @linxin666/dsh-client-ui-model-capabilities/client/DisabledProvidersFooter
 */
import type { RefreshBus, SettingsNamespaceFace } from './settings-face.ts';
/** Component props: the injected settings face and refresh bus. */
export interface DisabledProvidersFooterProps {
    /** The generated remote settings namespace (extracted by the apply body). */
    settings: SettingsNamespaceFace;
    /** Cross-surface refresh bus (a card-side toggle updates this listing). */
    refresh: RefreshBus;
}
/**
 * Render the disabled-provider archive.
 * @param props - the injected settings face and refresh bus.
 * @returns the footer area, or nothing while the archive is empty.
 */
export declare function DisabledProvidersFooter(props: DisabledProvidersFooterProps): import("react").JSX.Element | null;
