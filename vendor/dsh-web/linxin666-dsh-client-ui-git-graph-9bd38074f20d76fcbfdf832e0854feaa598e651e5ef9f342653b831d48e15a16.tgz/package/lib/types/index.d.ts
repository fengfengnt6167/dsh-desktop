/**
 * @linxin666/dsh-client-ui-git-graph — host half: the workspace-gated git
 * service and its /git/* HTTP routes (JSON operations + SSE change stream)
 * on the shared webserver, plus the opt-in model-facing git_worktree tool.
 * The browser half (exports "./client") is served by client-modules from
 * the same package's dsh.client declaration.
 *
 * The UI-triggered git verbs (switch/create-branch/worktree operations) own
 * no model-visible surface. The git_worktree tool is the deliberate,
 * settings-gated exception (agentTool, default off): while enabled, agents
 * may create/list/remove managed worktrees of their calling session's
 * repository.
 * @module @linxin666/dsh-client-ui-git-graph
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SettingsNamespace } from '@deepseek-ai/dsh-settings';
import z from 'schemastery';
/** Required services: the route registry, the managed subprocess seam, and the workspace registry. */
export declare const inject: string[];
/** Plugin config (settings-editable through the Web settings card). */
export interface Config {
    /** Auto-isolate every New Session of a git workspace into a fresh managed worktree. */
    autoIsolate?: boolean;
    /** Baseline for auto-created worktrees: the checkout's current HEAD or the remote default branch. */
    autoBaseline?: 'current' | 'default';
    /** Register the model-facing git_worktree tool (opt-in; off keeps git off the model-visible surface). */
    agentTool?: boolean;
}
/** Schemastery schema backing the settings card and profile patch values. */
export declare const Config: z<Config>;
/** The settings-card namespace of this plugin. */
export declare const GIT_GRAPH_SETTINGS: SettingsNamespace;
/**
 * Mount the git service, its routes, the settings card, and the opt-in tool.
 * @param ctx - context carrying webServer, subprocess, and workspaceRegistry.
 * @param config - profile patch values (the settings card re-sources them).
 */
export declare const apply: typeof applyImpl;
declare function applyImpl(ctx: Context, config?: Config): void;
export {};
//# sourceMappingURL=index.d.ts.map