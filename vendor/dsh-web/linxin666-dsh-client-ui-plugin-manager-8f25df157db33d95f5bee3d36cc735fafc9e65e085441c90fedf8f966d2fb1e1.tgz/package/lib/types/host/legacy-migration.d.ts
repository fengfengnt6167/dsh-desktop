/**
 * Deterministic mapping for the dsh-web aggregate package rename.
 *
 * The runtime identifiers (web-ui-* rows, settings section, API paths,
 * storage keys) stay frozen; only the npm aggregate package name changes.
 * This module is the single migration map shared by the plugin-manager
 * update job and the Doctor preflight launcher so they never drift.
 */
/** The previously published aggregate package name. */
export declare const LEGACY_AGGREGATE = "@linxin666/dsh-web-ui-all";
/** The current aggregate package name. */
export declare const CURRENT_AGGREGATE = "@linxin666/dsh-web-all";
/** One deterministic legacy-to-current package migration. */
export interface LegacyAggregateMigration {
    from: string;
    to: string;
}
/** The only supported legacy aggregate migration. */
export declare const LEGACY_AGGREGATE_MIGRATION: LegacyAggregateMigration;
/** Whether a package name is the legacy aggregate. */
export declare function isLegacyAggregate(name: string): boolean;
/** Whether a package name is the current aggregate. */
export declare function isCurrentAggregate(name: string): boolean;
/** Return the migration for a package name, or undefined when not legacy. */
export declare function legacyMigrationFor(name: string): LegacyAggregateMigration | undefined;
/**
 * Build the exact target install spec for one legacy aggregate source.
 *
 * Local repository links are rewritten in place so development checkouts
 * keep using the repository tree; every other source is migrated through the
 * published package pinned to the family release version.
 */
export declare function targetSpecForLegacy(sourceSpec: string, familyVersion: string): string | undefined;
