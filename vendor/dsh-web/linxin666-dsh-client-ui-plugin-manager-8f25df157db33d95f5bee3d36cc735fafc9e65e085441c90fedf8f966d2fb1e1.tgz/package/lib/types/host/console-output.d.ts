/**
 * Console-output capture shared by the family's Host halves.
 *
 * A child process's stdout/stderr are raw bytes, and on Windows a console
 * program writes the OEM code page (CP936/GBK on a zh-CN system), not UTF-8.
 * Decoding each chunk on its own corrupts the text twice over: the
 * encoding is guessed wrong, and a multi-byte character split across two reads
 * decodes into two replacement characters. This capture accumulates raw bytes
 * under a byte budget and decodes exactly once, at read time.
 */
/** Bounded byte accumulator for one child process's interleaved stdout/stderr. */
export interface OutputCapture {
    /** Append one raw chunk (the bytes are copied into the budget). */
    push(chunk: Uint8Array): void;
    /**
     * Decode everything captured so far. Idempotent, so a caller may read the
     * tail both after a failure branch and at settlement.
     */
    read(): string;
}
/**
 * Decode one console byte buffer. Strict UTF-8 wins whenever it is valid;
 * otherwise the bytes are not UTF-8 at all and the console wrote its own code
 * page, so the candidate that loses the least text is taken.
 * @param bytes - the captured bytes.
 * @returns the decoded text.
 */
export declare function decodeConsoleBytes(bytes: Uint8Array): string;
/**
 * Create a capture bounded to a byte budget. Overflow drops from the FRONT
 * (the tail is what carries a failure reason), and the cut never lands inside
 * a character: leading UTF-8 continuation bytes are dropped with it, and a
 * legacy code page's dangling lead byte — indistinguishable from a real byte
 * without knowing the encoding until the whole buffer is decoded — is removed
 * with the one replacement character it produced, so an over-long stream still
 * reads cleanly at the seam.
 * @param maxBytes - maximum retained bytes.
 * @returns the capture.
 */
export declare function createOutputCapture(maxBytes: number): OutputCapture;
