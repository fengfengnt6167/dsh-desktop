/**
 * Sidebar entry injection for the usage panel (issue #1592) — wiring over the
 * shared core. Unlike the panel-takeover family (task board / SSH / skill
 * center) this row does not participate in the family block, so it is placed
 * directly under the New Session row and ordered after those entries.
 * @module @linxin666/dsh-usage/client/sidebar-entry
 */
/** Stable data attribute identifying the injected entry row. */
export declare const ENTRY_SELECTOR = "[data-dsh-usage-entry]";
/** Locale-change subscription the shared core asks for (ctx.locale.subscribe shape). */
export interface LocaleRefreshSource {
    subscribe(listener: () => void): () => void;
}
/**
 * Mount the usage sidebar entry.
 * @param onToggle - toggles the panel below the row.
 * @param isOpen - reads the panel's expanded state (row highlight).
 * @param locale - locale-change source; when given, re-applies the label on a
 *   Language switch (the plain-DOM row otherwise keeps the mount-time copy).
 * @returns disposer removing the entry and its observers.
 */
export declare function mountSidebarEntry(onToggle: () => void, isOpen: () => boolean, locale?: LocaleRefreshSource): () => void;
