/**
 * Sidebar usage panel (issue #1592): a collapsible usage surface in the
 * sidebar, mounted directly under the family entry block. It reads the same
 * /api/dsh-usage/overview document the settings section renders — plan
 * providers show their quota windows, balance-only providers their remaining
 * amount — and polls only while the panel is expanded and the page visible.
 * @module @linxin666/dsh-usage/client/UsageSidebarPanel
 */
import { type ReactNode } from 'react';
import type { UsageStoreInstance } from './usage-store.ts';
/** Props of the sidebar panel (the apply body supplies the store and poller). */
export interface UsageSidebarPanelProps {
    store: UsageStoreInstance;
    /** Fetch one overview now. */
    poll: () => void;
    /** Force a host probe cycle now. */
    refresh: () => void;
}
/** localStorage key holding the collapsed flag ('1' = collapsed). */
export declare const COLLAPSED_STORAGE_KEY = "dsh-usage.sidebar.collapsed";
/**
 * Render the sidebar usage panel.
 * @param props - store plus the poll/refresh callbacks of the apply body.
 * @returns the panel body (no wrapper: the entry row owns the placement).
 */
export declare function UsageSidebarPanel(props: UsageSidebarPanelProps): ReactNode;
