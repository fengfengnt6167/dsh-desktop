/**
 * Sidebar usage panel mounting (issue #1592).
 *
 * The panel is a plain DOM row inserted into the sidebar right below the
 * usage entry row, carrying its own React root. Placement self-heals with the
 * same page-wide body-mutation hub the entry row uses; the entry row stays the
 * anchor, so the sidebar order never depends on this module's timing.
 * @module @linxin666/dsh-usage/client/sidebar-panel-mount
 */
import { type UsageSidebarPanelProps } from './UsageSidebarPanel.tsx';
/** Mounted panel controller: the entry row reads the open state to highlight. */
export interface UsagePanelMount {
    /** Whether the panel body is currently expanded. */
    isOpen(): boolean;
    /** Subscribe to open/collapse changes (the entry row's active highlight). */
    subscribe(listener: () => void): () => void;
    /** Open or collapse the panel. */
    toggle(): void;
    /** Unmount the panel and remove its container. */
    dispose(): void;
}
/**
 * Mount the sidebar usage panel below its entry row.
 * @param props - the store and poll/refresh callbacks of the apply body.
 * @returns the panel controller.
 */
export declare function mountUsagePanel(props: UsageSidebarPanelProps): UsagePanelMount;
